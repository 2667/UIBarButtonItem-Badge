//
//  XMGCommentViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/23.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGCommentViewController.h"
#import "XMGHTTPSessionManager.h"
#import "XMGTopic.h"
#import "XMGComment.h"
#import "XMGCommentCell.h"
#import <MJExtension.h>
#import <MJRefresh.h>
#import "XMGCommentHeaderView.h"
#import "XMGTopicCell.h"

@interface XMGCommentViewController () <UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomSpace;

/** 请求管理者 */
@property (nonatomic, weak) XMGHTTPSessionManager *manager;

/** 最热评论 数据 */
@property (nonatomic, strong) NSArray<XMGComment *> *hotestComments;

/** 最新评论 数据 */
@property (nonatomic, strong) NSMutableArray<XMGComment *> *latestComments;

/** 保存最热评论 */
@property (nonatomic, strong) id top_cmt;
@end

@implementation XMGCommentViewController

static NSString * const XMGCommentCellId = @"comment";
static NSString * const XMGHeaderId = @"header";

#pragma mark - 懒加载
/** manager属性的懒加载 */
- (XMGHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [XMGHTTPSessionManager manager];
    }
    return _manager;
}

#pragma mark - 初始化
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupBase];

    [self setupTable];
    
    [self setupTableHeader];
}

- (void)setupBase
{
    self.navigationItem.title = @"评论";
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

- (void)setupTable
{
    self.tableView.backgroundColor = XMGCommonBgColor;
    self.tableView.sectionHeaderHeight = [UIFont systemFontOfSize:16].lineHeight;
    
    // 让cell的高度自动计算
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 100;
    
    // 注册
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([XMGCommentCell class]) bundle:nil] forCellReuseIdentifier:XMGCommentCellId];
    [self.tableView registerClass:[XMGCommentHeaderView class] forHeaderFooterViewReuseIdentifier:XMGHeaderId];
    
    // 刷新控件
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewComments)];
    [self.tableView.header beginRefreshing];
    
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreComments)];
}

- (void)setupTableHeader
{
    // 处理模型数据
    if(self.topic.top_cmt) {
        self.top_cmt = self.topic.top_cmt;
        self.topic.top_cmt = nil;
        self.topic.cellHeight = 0;
    }
    
    // 头部控件
    UIView *headerView = [[UIView alloc] init];
    
    // 添加cell到headerView中
    XMGTopicCell *cell = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([XMGTopicCell class]) owner:nil options:nil].lastObject;
//    cell.contentView.backgroundColor = [UIColor clearColor];
//    cell.backgroundColor = [UIColor clearColor];
    // 设置模型数据
    cell.topic = self.topic;
    // 设置cell的frame
    cell.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, self.topic.cellHeight);
    // 设置cell的高度
//    cell.height = self.topic.cellHeight;
//    cell.width = [UIScreen mainScreen].bounds.size.width;
    [headerView addSubview:cell];
    
    // 设置headerView的高度
    headerView.height = cell.height + 2 * XMGMargin;
    
    // 设置header
    self.tableView.tableHeaderView = headerView;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    if (self.top_cmt) { // 如果有最热评论, 就重新赋值评论, 重新计算cell的高度
        self.topic.top_cmt = self.top_cmt;
        self.topic.cellHeight = 0;
    }
}

#pragma mark - 加载数据
- (void)loadNewComments
{
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    // 请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a"] = @"dataList";
    params[@"hot"] = @"1";
    params[@"c"] = @"comment";
    params[@"data_id"] = self.topic.ID;
    
    // 发送请求
    __weak typeof(self) weakSelf = self;
    [self.manager GET:XMGRequestURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        if ([responseObject isKindOfClass:[NSArray class]]) { // 没有评论数据
            // 结束刷新
            [weakSelf.tableView.header endRefreshing];
            return;
        }
        
        // 字典数组 -> 模型数组
        weakSelf.hotestComments = [XMGComment objectArrayWithKeyValuesArray:responseObject[@"hot"]];
        weakSelf.latestComments = [XMGComment objectArrayWithKeyValuesArray:responseObject[@"data"]];
        
        // 刷新表格
        [weakSelf.tableView reloadData];
        
        // 结束刷新
        [weakSelf.tableView.header endRefreshing];
        
        NSInteger total = [responseObject[@"total"] integerValue];
        if (weakSelf.latestComments.count == total) { // 没有更多数据
            weakSelf.tableView.footer.hidden = YES;
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        // 结束刷新
        [weakSelf.tableView.header endRefreshing];
    }];
}

- (void)loadMoreComments
{
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    // 请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a"] = @"dataList";
    params[@"c"] = @"comment";
    params[@"data_id"] = self.topic.ID;
    params[@"lastcid"] = self.latestComments.lastObject.ID;
    
    // 发送请求
    __weak typeof(self) weakSelf = self;
    [self.manager GET:XMGRequestURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        if ([responseObject isKindOfClass:[NSArray class]]) { // 没有评论数据
            // 结束刷新
            weakSelf.tableView.footer.hidden = YES;
            return;
        }
        
        // 字典数组 -> 模型数组
        NSArray *moreComments = [XMGComment objectArrayWithKeyValuesArray:responseObject[@"data"]];
        [weakSelf.latestComments addObjectsFromArray:moreComments];
        
        // 刷新表格
        [weakSelf.tableView reloadData];
        
        // 结束刷新
        NSInteger total = [responseObject[@"total"] integerValue];
        if (weakSelf.latestComments.count == total) { // 没有更多数据
//            [weakSelf.tableView.footer endRefreshingWithNoMoreData];
            weakSelf.tableView.footer.hidden = YES;
        } else {
            [weakSelf.tableView.footer endRefreshing];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        // 结束刷新
        [weakSelf.tableView.footer endRefreshing];
    }];
}

#pragma mark - 监听
- (void)keyboardWillChangeFrame:(NSNotification *)note
{
    // 设置约束值
    CGRect keyboardF = [note.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    self.bottomSpace.constant = [UIScreen mainScreen].bounds.size.height - keyboardF.origin.y;
    
    // 动画
    CGFloat duration = [note.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    [UIView animateWithDuration:duration animations:^{
        [self.view layoutIfNeeded];
    }];
}

#pragma mark - 数据源方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (self.hotestComments.count) return 2;
    if (self.latestComments.count) return 1;
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.hotestComments.count && section == 0) return self.hotestComments.count;
    return self.latestComments.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMGCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGCommentCellId];
    
    if (self.hotestComments.count && indexPath.section == 0) { // 从最热评论中取出数据
        cell.comment = self.hotestComments[indexPath.row];
    } else {
        cell.comment = self.latestComments[indexPath.row];
    }
    
    return cell;
}

#pragma mark - 代理方法
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

//- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
//{
//    if (self.hotestComments.count && section == 0) return @"最热评论";
//    return @"最新评论";
//}

/*
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    // 创建header
    UIView *headerView = [[UIView alloc] init];
    headerView.backgroundColor = XMGCommonBgColor;
    
    // 添加label
    UILabel *label = [[UILabel alloc] init];
    [headerView addSubview:label];
    
    // 设置label
    label.x = 10;
    label.width = 100;
    label.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    label.font = [UIFont systemFontOfSize:14];
    label.textColor = [UIColor darkGrayColor];
    if (self.hotestComments.count && section == 0) {
//        label.text = @"   最热评论";
        label.text = @"最热评论";
    } else {
//        label.text = @"   最新评论";
        label.text = @"最新评论";
    }
    
    return headerView;
}
*/
//- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    // 创建header
    XMGCommentHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:XMGHeaderId];
    
    // 设置数据
    if (self.hotestComments.count && section == 0) {
        headerView.text = @"最热评论";
    } else {
        headerView.text = @"最新评论";
    }
    return headerView;
}
@end
