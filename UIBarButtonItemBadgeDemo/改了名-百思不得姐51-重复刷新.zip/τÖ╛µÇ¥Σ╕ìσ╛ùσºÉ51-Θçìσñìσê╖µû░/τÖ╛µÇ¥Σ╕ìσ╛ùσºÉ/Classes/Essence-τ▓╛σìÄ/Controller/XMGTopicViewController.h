//
//  XMGTopicViewController.h
//  百思不得姐
//
//  Created by xiaomage on 15/10/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMGTopic.h"

@interface XMGTopicViewController : UITableViewController
/** 帖子类型 */
- (XMGTopicType)type;

//@property (nonatomic, assign) XMGTopicType type;
@end
