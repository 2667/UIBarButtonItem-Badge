//
//  XMGWordViewController.h
//  百思不得姐
//
//  Created by xiaomage on 15/10/15.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGTopicViewController.h"

@interface XMGWordViewController : XMGTopicViewController

@end
