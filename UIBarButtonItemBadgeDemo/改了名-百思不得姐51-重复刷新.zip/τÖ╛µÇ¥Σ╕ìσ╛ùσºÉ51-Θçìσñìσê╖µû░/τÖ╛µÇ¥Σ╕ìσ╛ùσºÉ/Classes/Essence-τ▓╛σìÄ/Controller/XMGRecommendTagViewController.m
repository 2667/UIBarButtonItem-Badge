//
//  XMGRecommendTagViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/8.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGRecommendTagViewController.h"
#import "XMGHTTPSessionManager.h"
#import <MJExtension.h>
#import "XMGRecommendTag.h"
#import "XMGRecommendTagCell.h"
#import <SVProgressHUD.h>
#import <MJRefresh.h>
#import "XMGDIYHeader.h"

@interface XMGRecommendTagViewController ()
/** 所有的标签数据(数组中存放的都是XMGRecommendTag模型) */
@property (nonatomic, strong) NSArray *recommendTags;
/** 任务 */
//@property (nonatomic, strong) NSURLSessionDataTask *task;
/** 请求管理者 */
@property (nonatomic, weak) XMGHTTPSessionManager *manager;
@end

@implementation XMGRecommendTagViewController

/** manager属性的懒加载 */
- (XMGHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [XMGHTTPSessionManager manager];
    }
    return _manager;
}

/** cell的重用标识 */
static NSString * const XMGRecommendTagCellId = @"recommendTag";

#pragma mark - 初始化
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 基本设置
    self.title = @"推荐标签";
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([XMGRecommendTagCell class]) bundle:nil] forCellReuseIdentifier:XMGRecommendTagCellId];
    self.tableView.rowHeight = 70;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = XMGCommonBgColor;
    
    // 测试刷新控件
    __weak typeof(self) weakSelf = self;
    self.tableView.header = [XMGDIYHeader headerWithRefreshingBlock:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf.tableView.header endRefreshing];
        });
    }];
    
    // 加载标签数据
    [self loadNewRecommandTags];
}

/**
 *  加载标签数据
 */
- (void)loadNewRecommandTags
{
    // 弱引用
    __weak typeof(self) weakSelf = self;
    
    // 弹框
    [SVProgressHUD show];
    
    // 请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a"] = @"tag_recommend";
    params[@"action"] = @"sub";
    params[@"c"] = @"topic";
    
    // 发送请求
    [self.manager GET:XMGRequestURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        // responseObject : 字典数组 -> self.recommandTags : 模型数组
        weakSelf.recommendTags = [XMGRecommendTag objectArrayWithKeyValuesArray:responseObject];
        
        // 刷新表格
        [weakSelf.tableView reloadData];
        
        // 隐藏弹框
        [SVProgressHUD dismiss];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        // 如果是因为取消任务来到这个block, 就直接返回
        if (error.code == NSURLErrorCancelled) return;
        
        // 隐藏弹框
//        [SVProgressHUD dismiss];
        
        // 提示失败信息
        [SVProgressHUD showErrorWithStatus:@"加载推荐标签数据失败!"];
    }];
}

- (void)dealloc
{
    XMGLogFuc;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    // 隐藏弹框
    [SVProgressHUD dismiss];
    
    // 取消当前的所有请求
    [self.manager invalidateSessionCancelingTasks:YES];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.recommendTags.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMGRecommendTagCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGRecommendTagCellId];
    
    cell.recommendTag = self.recommendTags[indexPath.row];
    
    return cell;
}
@end
