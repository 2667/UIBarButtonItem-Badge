//
//  XMGSeeBigViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGSeeBigViewController.h"
#import "XMGTopic.h"
#import <UIImageView+WebCache.h>
#import <SVProgressHUD.h>
#import <AssetsLibrary/AssetsLibrary.h> // 从iOS9开始完全废弃
#import <Photos/Photos.h> // 从iOS8开始可用

@interface XMGSeeBigViewController () <UIScrollViewDelegate>
@property (nonatomic, weak) UIImageView *imageView;
@end

@implementation XMGSeeBigViewController

static NSString * const XMGCollectionName = @"百思不得姐";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // scrollView
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.delegate = self;
    scrollView.frame = [UIScreen mainScreen].bounds;
//    scrollView.frame = self.view.bounds;
//    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.view insertSubview:scrollView atIndex:0];
    
    // imageView
    UIImageView *imageView = [[UIImageView alloc] init];
    [imageView sd_setImageWithURL:[NSURL URLWithString:self.topic.large_image]];
    imageView.width = scrollView.width;
    imageView.height = self.topic.height * imageView.width / self.topic.width;
    imageView.x = 0;
    if (imageView.height >= scrollView.height) { // 图片高度超过整个屏幕
        imageView.y = 0;
    } else { // 居中显示
        imageView.centerY = scrollView.height * 0.5;
    }
    [scrollView addSubview:imageView];
    self.imageView = imageView;
    
    // 滚动范围
    scrollView.contentSize = CGSizeMake(0, imageView.height);
    
    // 缩放比例
    CGFloat maxScale = self.topic.height / imageView.height;
    if (maxScale > 1.0) {
        scrollView.maximumZoomScale = maxScale;
    }
}

- (IBAction)back {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)save {
    // 0.判断状态
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusDenied) { // 用户拒绝当前应用访问相册
        XMGLog(@"用户拒绝当前应用访问相册 - 提醒用户打开访问开关");
    } else if (status == PHAuthorizationStatusRestricted) { // 家长控制
        XMGLog(@"家长控制 - 不允许访问");
    } else if (status == PHAuthorizationStatusNotDetermined) { // 用户还没有做出选择
        XMGLog(@"用户还没有做出选择");
        
        [self saveImage];
    } else if (status == PHAuthorizationStatusAuthorized) { // 用户允许当前应用访问相册
        XMGLog(@"用户允许当前应用访问相册");
        
        [self saveImage];
    }
}

/**
 *  返回相册
 */
- (PHAssetCollection *)collection
{
    // 先获得之前创建过的相册
    PHFetchResult<PHAssetCollection *> *collectionResult = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    for (PHAssetCollection *collection in collectionResult) {
        if ([collection.localizedTitle isEqualToString:XMGCollectionName]) {
            return collection;
        }
    }
    
    // 如果相册不存在, 就创建新的相册(文件夹)
    __block NSString *collectionId = nil;
//    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
//        // 新建一个PHAssetCollectionChangeRequest对象, 用来创建一个新的相册
//        collectionId = [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:XMGCollectionName].placeholderForCreatedAssetCollection.localIdentifier;
//    } completionHandler:^(BOOL success, NSError * _Nullable error) {
//        collection = [PHAssetCollection fetchAssetCollectionsWithLocalIdentifiers:@[collectionId] options:nil].firstObject;
//    }];
    
    
    // 这个方法会在相册创建完毕后才会返回
    [[PHPhotoLibrary sharedPhotoLibrary] performChangesAndWait:^{
        // 新建一个PHAssetCollectionChangeRequest对象, 用来创建一个新的相册
        collectionId = [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:XMGCollectionName].placeholderForCreatedAssetCollection.localIdentifier;
    } error:nil];
    
    return [PHAssetCollection fetchAssetCollectionsWithLocalIdentifiers:@[collectionId] options:nil].firstObject;
}

/**
 *  保存图片到相册
 */
- (void)saveImage
{
    /*
     PHAsset : 一个PHAsset对象就代表一个资源文件, 比如一张图片
     
     PHAssetCollection : 一个PHAssetCollection对象就代表一个相册
     */
    
    __block NSString *assetId = nil;
    
    // 1.存储图片到"相机胶卷"
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{ // 这个block里面存放一些"修改"性质的代码
        // 新建一个PHAssetCreationRequest对象, 保存图片到"相机胶卷"
        // 返回PHAsset(图片)的字符串标识
        assetId = [PHAssetCreationRequest creationRequestForAssetFromImage:self.imageView.image].placeholderForCreatedAsset.localIdentifier;
    } completionHandler:^(BOOL success, NSError * _Nullable error) {
        if (error) {
            XMGLog(@"保存图片到相机胶卷中失败");
            return;
        }
        
        XMGLog(@"成功保存图片到相机胶卷中");
        
        // 2.获得相册对象
        PHAssetCollection *collection = [self collection];
        
        // 3.将"相机胶卷"中的图片 添加到 新的相册
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            PHAssetCollectionChangeRequest *reqeust = [PHAssetCollectionChangeRequest changeRequestForAssetCollection:collection];
            
            // 根据唯一标识获得相片对象
            PHAsset *asset = [PHAsset fetchAssetsWithLocalIdentifiers:@[assetId] options:nil].firstObject;
            // 添加图片到相册中
            [reqeust addAssets:@[asset]];
        } completionHandler:^(BOOL success, NSError * _Nullable error) {
            if (error) {
                XMGLog(@"添加图片到相册中失败");
                return;
            }
            
            XMGLog(@"成功添加图片到相册中");
            [[NSOperationQueue mainQueue] addOperationWithBlock:^{
                [SVProgressHUD showSuccessWithStatus:@"保存成功"];
            }];
        }];
    }];
}

#pragma mark - <UIScrollViewDelegate>
/**
 *  返回一个scrollView内部的子控件进行缩放
 */
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}
@end
