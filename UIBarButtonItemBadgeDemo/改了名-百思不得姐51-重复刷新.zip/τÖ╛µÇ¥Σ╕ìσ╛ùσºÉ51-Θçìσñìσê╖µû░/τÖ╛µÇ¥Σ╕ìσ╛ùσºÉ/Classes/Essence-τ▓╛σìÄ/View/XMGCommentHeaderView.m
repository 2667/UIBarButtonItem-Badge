//
//  XMGCommentHeaderView.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/26.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGCommentHeaderView.h"

@interface XMGCommentHeaderView()
/** label */
@property (nonatomic, weak) UILabel *label;
@end

@implementation XMGCommentHeaderView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = XMGCommonBgColor;
        
        // 添加label
        UILabel *label = [[UILabel alloc] init];
        [self.contentView addSubview:label];
        
        // 设置label
        label.x = 10;
        label.width = 100;
        label.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        label.font = [UIFont systemFontOfSize:14];
        label.textColor = [UIColor darkGrayColor];
        self.label = label;
    }
    return self;
}

- (void)setText:(NSString *)text
{
    _text = [text copy];

    self.label.text = text;
}
@end
