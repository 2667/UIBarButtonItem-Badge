//
//  XMGTopicCenterView.h
//  百思不得姐
//
//  Created by xiaomage on 15/10/22.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGTopic;

@interface XMGTopicCenterView : UIView
{
    __weak UIImageView *_imageView;
}

+ (instancetype)centerView;

/** 帖子模型数据 */
@property (nonatomic, strong) XMGTopic *topic;
@end
