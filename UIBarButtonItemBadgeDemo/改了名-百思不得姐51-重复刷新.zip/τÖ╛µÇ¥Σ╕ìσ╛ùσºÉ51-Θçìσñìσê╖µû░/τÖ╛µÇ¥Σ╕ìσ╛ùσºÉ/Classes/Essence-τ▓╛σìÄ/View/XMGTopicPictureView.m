//
//  XMGTopicPictureView.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/18.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGTopicPictureView.h"
#import "XMGTopic.h"
#import <UIImageView+WebCache.h>
#import <DALabeledCircularProgressView.h>
#import "XMGSeeBigViewController.h"

@interface XMGTopicPictureView()
@property (weak, nonatomic) IBOutlet UIButton *seeBigButton;
@property (weak, nonatomic) IBOutlet UIImageView *gifView;
@property (weak, nonatomic) IBOutlet UIImageView *placeholderView;
@property (weak, nonatomic) IBOutlet DALabeledCircularProgressView *progressView;
@end

@implementation XMGTopicPictureView
- (void)awakeFromNib
{
    [super awakeFromNib];
    
    // 初始化
    self.progressView.roundedCorners = 5;
    self.progressView.progressLabel.textColor = [UIColor whiteColor];
}

- (void)setTopic:(XMGTopic *)topic
{
    [super setTopic:topic];

    // 显示图片
    [_imageView sd_setImageWithURL:[NSURL URLWithString:topic.large_image] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize) { // 这个block可能会被调用多次
        if (receivedSize < 0 || expectedSize < 0) return;
        
        // 显示正在下载的提醒
        self.progressView.hidden = NO;
        self.placeholderView.hidden = NO;
        
        // 显示进度值
        CGFloat progress = 1.0 * receivedSize / expectedSize;
        self.progressView.progress = progress;
        
        self.progressView.progressLabel.text = [NSString stringWithFormat:@"%.0f%%", progress * 100];
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) { // 下载完毕
        // 隐藏正在下载的提醒
        self.placeholderView.hidden = YES;
        self.progressView.hidden = YES;
    }];
    
    // 是否为gif
    self.gifView.hidden = !topic.is_gif;

    // 查看大图
    self.seeBigButton.hidden = !topic.isBigPicture;
    if (topic.isBigPicture) {
        _imageView.contentMode = UIViewContentModeTop;
        _imageView.clipsToBounds = YES;
    } else {
        _imageView.contentMode = UIViewContentModeScaleToFill;
        _imageView.clipsToBounds = NO;
    }
}
@end
