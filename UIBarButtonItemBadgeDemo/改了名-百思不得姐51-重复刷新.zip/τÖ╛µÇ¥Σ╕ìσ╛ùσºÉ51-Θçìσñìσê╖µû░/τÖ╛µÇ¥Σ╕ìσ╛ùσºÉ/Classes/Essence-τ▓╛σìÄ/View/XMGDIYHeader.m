//
//  XMGDIYHeader.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/16.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGDIYHeader.h"

@implementation XMGDIYHeader
- (void)prepare
{
    // - (void)prepare NS_REQUIRES_SUPER;
    [super prepare];
    
    self.lastUpdatedTimeLabel.hidden = YES;
    self.stateLabel.textColor = [UIColor yellowColor];
    [self setTitle:@"下拉肯定可以刷新" forState:MJRefreshStateIdle];
    [self setTitle:@"松开🐴上就可以刷新" forState:MJRefreshStatePulling];
    [self setTitle:@"哥正在帮你刷新..." forState:MJRefreshStateRefreshing];
    // 自动调整透明度x
    self.automaticallyChangeAlpha = YES;
    
//    [self addSubview:[[UISwitch alloc] init]];
//    
//    UIImageView *logo = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Snip20151016_1462"]];
//    logo.width = 200;
//    logo.height = 50;
//    logo.bottom = 0;
//    logo.centerX = [UIScreen mainScreen].bounds.size.width * 0.5;
//    [self addSubview:logo];
}
@end
