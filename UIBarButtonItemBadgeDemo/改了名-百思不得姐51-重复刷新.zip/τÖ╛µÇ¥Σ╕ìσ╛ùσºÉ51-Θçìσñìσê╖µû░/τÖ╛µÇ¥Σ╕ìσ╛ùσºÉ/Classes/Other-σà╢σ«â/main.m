//
//  main.m
//  百思不得姐
//
//  Created by xiaomage on 15/9/28.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

// NaN == Not a Number 一般是x / 0导致

// int age = 20 / 0;
