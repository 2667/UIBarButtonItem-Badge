//
//  NSObject+XMGExtension.h
//  百思不得姐
//
//  Created by xiaomage on 15/10/8.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (XMGExtension)
/**
 *  打印出所有的成员变量
 */
+ (void)logAllIvars;
@end
