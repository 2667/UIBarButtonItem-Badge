//
//  XMGHTTPSessionManager.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/11.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGHTTPSessionManager.h"

@implementation XMGHTTPSessionManager
+ (instancetype)manager
{
    // text/json
    // text/xml
    // text/plain
    // text/html
    XMGHTTPSessionManager *mgr = [super manager];
//    mgr.responseSerializer = ;
//    mgr.requestSerializer = ;
    return mgr;
}
@end
