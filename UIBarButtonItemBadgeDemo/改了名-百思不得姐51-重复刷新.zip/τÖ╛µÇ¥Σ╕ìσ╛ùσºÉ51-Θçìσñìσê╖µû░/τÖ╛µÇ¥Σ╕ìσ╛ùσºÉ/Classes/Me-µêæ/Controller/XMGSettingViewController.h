//
//  XMGSettingViewController.h
//  百思不得姐
//
//  Created by xiaomage on 15/9/29.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGSettingViewController : UITableViewController

@end
