//
//  XMGSettingViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/9/29.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGSettingViewController.h"
#import <SDImageCache.h>
#import "XMGClearCacheCell.h"
#import "XMGSettingCell.h"
#import "XMGOtherCell.h"

@interface XMGSettingViewController ()

@end

@implementation XMGSettingViewController

static NSString * const XMGClearCacheCellId = @"clear_cache";
static NSString * const XMGSettingCellId = @"setting";
static NSString * const XMGOtherCellId = @"other";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"设置";
    // 注册
    [self.tableView registerClass:[XMGClearCacheCell class] forCellReuseIdentifier:XMGClearCacheCellId];
    [self.tableView registerClass:[XMGSettingCell class] forCellReuseIdentifier:XMGSettingCellId];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([XMGOtherCell class]) bundle:nil] forCellReuseIdentifier:XMGOtherCellId];
    
    self.tableView.backgroundColor = XMGCommonBgColor;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 15;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (indexPath.row == 0) { // 清除缓存
//            XMGClearCacheCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGClearCacheCellId];
//            [cell updateStatus];
//            return cell;
            return [tableView dequeueReusableCellWithIdentifier:XMGClearCacheCellId];
        } else { // 其他cell
            XMGSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGSettingCellId];
            
            if (indexPath.row == 1) {
                cell.textLabel.text = @"检查更新";
            } else if (indexPath.row == 2) {
                cell.textLabel.text = @"给我们评分";
            } else if (indexPath.row == 3) {
                cell.textLabel.text = @"推送设置";
            } else {
                cell.textLabel.text = @"关于我们";
            }
            
            return cell;
        }
    } else {
        return [tableView dequeueReusableCellWithIdentifier:XMGOtherCellId];
    }
}

#pragma mark - delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMGLogFuc;
}
@end
