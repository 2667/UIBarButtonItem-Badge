//
//  XMGMeViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/9/28.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGMeViewController.h"
#import "XMGSettingViewController.h"
#import "XMGMeCell.h"
#import "XMGMeFooter.h"

@interface XMGMeViewController ()

@end

@implementation XMGMeViewController

static NSString * const XMGMeCellId = @"me";

#pragma mark - 初始化
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置表格
    [self setupTable];
    
    // 设置导航栏
    [self setupNav];
}

/**
 *  设置表格
 */
- (void)setupTable
{
    self.tableView.backgroundColor = XMGCommonBgColor;
    [self.tableView registerClass:[XMGMeCell class] forCellReuseIdentifier:XMGMeCellId];
    self.tableView.sectionHeaderHeight = 0;
    self.tableView.sectionFooterHeight = XMGMargin;
    self.tableView.contentInset = UIEdgeInsetsMake(XMGMargin - XMGGorupFirstCellY, 0, 0, 0);
    
    // 设置footer
    self.tableView.tableFooterView = [[XMGMeFooter alloc] init];
}

/**
 *  设置导航栏
 */
- (void)setupNav
{
    // 设置标题
    self.navigationItem.title = @"我的";
    // 设置右上角
    UIBarButtonItem *moonItem = [UIBarButtonItem itemWithImage:@"mine-moon-icon" highImage:@"mine-moon-icon-click" target:self action:@selector(moonClick)];
    UIBarButtonItem *settingItem = [UIBarButtonItem itemWithImage:@"mine-setting-icon" highImage:@"mine-setting-icon-click" target:self action:@selector(settingClick)];
    self.navigationItem.rightBarButtonItems = @[settingItem, moonItem];
}

#pragma mark - 监听
- (void)moonClick
{
    XMGLogFuc
}

- (void)settingClick
{
    XMGSettingViewController *setting = [[XMGSettingViewController alloc] initWithStyle:UITableViewStyleGrouped];
    [self.navigationController pushViewController:setting animated:YES];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    XMGMeCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGMeCellId];
    
    if (indexPath.section == 0) {
        cell.textLabel.text = @"登录/注册";
        cell.imageView.image = [UIImage imageNamed:@"publish-audio"];
    } else {
        cell.textLabel.text = @"离线下载";
        cell.imageView.image = nil; // 写上这句会更加严谨
    }
    
    return cell;
}

@end
