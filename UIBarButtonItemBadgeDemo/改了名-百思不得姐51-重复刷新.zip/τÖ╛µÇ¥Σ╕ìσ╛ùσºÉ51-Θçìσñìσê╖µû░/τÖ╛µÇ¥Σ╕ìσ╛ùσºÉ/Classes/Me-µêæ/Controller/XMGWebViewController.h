//
//  XMGWebViewController.h
//  百思不得姐
//
//  Created by xiaomage on 15/10/11.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGWebViewController : UIViewController
/** 需要显示的网页链接 */
@property (nonatomic, copy) NSString *url;
@end
