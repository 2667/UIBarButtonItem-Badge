//
//  XMGSettingCell.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/12.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGSettingCell.h"

@implementation XMGSettingCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
