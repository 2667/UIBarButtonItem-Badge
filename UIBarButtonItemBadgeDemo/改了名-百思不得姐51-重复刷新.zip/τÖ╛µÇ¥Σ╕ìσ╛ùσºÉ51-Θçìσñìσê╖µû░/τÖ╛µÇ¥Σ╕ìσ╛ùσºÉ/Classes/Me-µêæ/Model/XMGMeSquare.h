//
//  XMGMeSquare.h
//  百思不得姐
//
//  Created by xiaomage on 15/10/11.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMGMeSquare : NSObject
/** 图标 */
@property (nonatomic, copy) NSString *icon;
/** 名字 */
@property (nonatomic, copy) NSString *name;
/** 链接 */
@property (nonatomic, copy) NSString *url;
@end
