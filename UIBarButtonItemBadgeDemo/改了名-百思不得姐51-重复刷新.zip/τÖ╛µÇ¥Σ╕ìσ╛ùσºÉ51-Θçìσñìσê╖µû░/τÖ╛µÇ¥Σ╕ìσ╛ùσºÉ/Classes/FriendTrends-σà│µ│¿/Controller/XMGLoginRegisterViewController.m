//
//  XMGLoginRegisterViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/9/30.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginRegisterViewController.h"

@interface XMGLoginRegisterViewController ()
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *leftMargin;
@end

@implementation XMGLoginRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];

//    [XMGStatusBarViewController sharedInstace].showingVc = self;
}

//- (UIStatusBarStyle)preferredStatusBarStyle
//{
//    return UIStatusBarStyleLightContent;
//}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [XMGStatusBarViewController sharedInstace].statusBarStyle = UIStatusBarStyleLightContent;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [XMGStatusBarViewController sharedInstace].statusBarStyle = UIStatusBarStyleDefault;
}

- (IBAction)loginOrRegister:(UIButton *)button {
    // 修改按钮的选中状态
    button.selected = !button.isSelected;
    
    // 修改约束
    if (self.leftMargin.constant) {
        self.leftMargin.constant = 0;
    } else {
        self.leftMargin.constant = - self.view.width;
    }
    
    // 执行动画
    [UIView animateWithDuration:0.25 animations:^{
        [self.view layoutIfNeeded];
    }];
    
    // 退出键盘
    [self.view endEditing:YES];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
@end
