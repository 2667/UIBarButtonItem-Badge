//
//  XMGRecommendFollowViewController.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/23.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGRecommendFollowViewController.h"
#import "XMGRecommendCategoryCell.h"
#import "XMGRecommendUserCell.h"
#import "XMGHTTPSessionManager.h"
#import "XMGRecommendCategory.h"
#import "XMGRecommendUser.h"
#import <MJExtension.h>
#import <SVProgressHUD.h>
#import "XMGDIYHeader.h"
#import "XMGDIYFooter.h"

@interface XMGRecommendFollowViewController () <UITableViewDataSource, UITableViewDelegate>
/** 👈 - 类别表格 */
@property (weak, nonatomic) IBOutlet UITableView *categoryTable;
/** 👉 - 用户表格 */
@property (weak, nonatomic) IBOutlet UITableView *userTable;
/** 请求管理者 */
@property (nonatomic, weak) XMGHTTPSessionManager *manager;
/** 👈 - 所有的类别数据 */
@property (nonatomic, strong) NSArray<XMGRecommendCategory *> *categories;
/** 👉 - 用户数据 */
//@property (nonatomic, strong) NSArray<XMGRecommendUser *> *users;
/** 存放所有的用户数据 */
//@property (nonatomic, strong) NSMutableDictionary *allUsers;
@end

@implementation XMGRecommendFollowViewController
#pragma mark - 懒加载
//- (NSMutableDictionary *)allUsers
//{
//    if (!_allUsers) {
//        _allUsers = [NSMutableDictionary dictionary];
//    }
//    return _allUsers;
//}

/** manager属性的懒加载 */
- (XMGHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [XMGHTTPSessionManager manager];
    }
    return _manager;
}

/** cell的重用标识 */
static NSString * const XMGCategoryCellId = @"category";
static NSString * const XMGUserCellId = @"user";

#pragma mark - 初始化
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = XMGCommonBgColor;
    
    // 设置表格
    [self setupTable];
    
    // 加载 👈 - 类别表格 数据
    [self loadCategories];
}

/**
 *  设置表格
 */
- (void)setupTable
{
    UIEdgeInsets inset = UIEdgeInsetsMake(XMGNavBarBottom, 0, 0, 0);
    self.categoryTable.contentInset = inset;
    self.categoryTable.scrollIndicatorInsets = inset;
    self.userTable.contentInset = inset;
    self.userTable.scrollIndicatorInsets = inset;
    
    self.userTable.header = [XMGDIYHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewUsers)];
    self.userTable.footer = [XMGDIYFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreUsers)];
//    self.userTable.footer.automaticallyHidden = NO;
}

#pragma mark - 加载数据
/**
 *  加载更多的用户数据
 */
- (void)loadMoreUsers
{
    // 取消之前的请求
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    // 当前选中的类别模型
    XMGRecommendCategory *category = self.categories[self.categoryTable.indexPathForSelectedRow.row];
    
    // 请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a"] = @"list";
    params[@"c"] = @"subscribe";
    params[@"category_id"] = category.id;
    NSInteger page = category.page + 1;
    params[@"page"] = @(page);
    
    // 发送请求
    __weak typeof(self) weakSelf = self;
    [self.manager GET:XMGRequestURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        // 赋值新的页码
        category.page = page;
        
        // 字典数组 -> 模型数组
        NSArray *moreUsers = [XMGRecommendUser objectArrayWithKeyValuesArray:responseObject[@"list"]];
        [category.users addObjectsFromArray:moreUsers];
        
        // 总数
        category.total = [responseObject[@"total"] integerValue];
        
        // 刷新👉 - 用户表格
        [weakSelf.userTable reloadData];
        
        // 结束刷新
        if (category.users.count == category.total) { // 所有用户数据加载完毕 - 提醒用户加载完全
//            [weakSelf.userTable.footer endRefreshingWithNoMoreData];
            weakSelf.userTable.footer.hidden = YES;
        } else { // 用户数据还没有加载完全 - 结束刷新
            [weakSelf.userTable.footer endRefreshing];
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        // 结束刷新
        [weakSelf.userTable.footer endRefreshing];
    }];
}

/**
 *  加载最新的用户数据
 */
- (void)loadNewUsers
{
    // 取消之前的请求
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    // 当前选中的类别模型
    XMGRecommendCategory *category = self.categories[self.categoryTable.indexPathForSelectedRow.row];
    
    // 请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a"] = @"list";
    params[@"c"] = @"subscribe";
    params[@"category_id"] = category.id;
    
    // 发送请求
    __weak typeof(self) weakSelf = self;
    [self.manager GET:XMGRequestURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        // 赋值新页码
        category.page = 1;
        
        // 字典数组 -> 模型数组
        category.users = [XMGRecommendUser objectArrayWithKeyValuesArray:responseObject[@"list"]];
        
        // 总数
        category.total = [responseObject[@"total"] integerValue];
        
        // 刷新👉 - 用户表格
        [weakSelf.userTable reloadData];
        
        // 结束刷新
        [weakSelf.userTable.header endRefreshing];
        
        if (category.users.count == category.total) { // 所有用户数据加载完毕 - 提醒用户加载完全
            weakSelf.userTable.footer.hidden = YES;
        }
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        // 结束刷新
        [weakSelf.userTable.header endRefreshing];
    }];
}

/**
 *  加载 👈 - 类别表格 数据
 */
- (void)loadCategories
{
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    
    // 请求参数
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"a"] = @"category";
    params[@"c"] = @"subscribe";
    
    // 发送请求
    __weak typeof(self) weakSelf = self;
    [self.manager GET:XMGRequestURL parameters:params success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
        // 字典数组 -> 模型数组
        weakSelf.categories = [XMGRecommendCategory objectArrayWithKeyValuesArray:responseObject[@"list"]];
        
        // 刷新👈 - 类别表格
        [weakSelf.categoryTable reloadData];
        
        // 选中第0行
        [weakSelf.categoryTable selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
        
        // 让👉 - 用户表格
        [weakSelf.userTable.header beginRefreshing];
        
        // 隐藏
        [SVProgressHUD dismiss];
    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        // 隐藏
        [SVProgressHUD dismiss];
    }];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.categoryTable) { // 👈 - 类别表格
        return self.categories.count;
    } else { // 👉 - 用户表格
        XMGRecommendCategory *category = self.categories[self.categoryTable.indexPathForSelectedRow.row];
        return category.users.count;
//        return [self.allUsers[category.name] count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.categoryTable) { // 👈 - 类别表格
        XMGRecommendCategoryCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGCategoryCellId];
        
        cell.category = self.categories[indexPath.row];
        
        return cell;
    } else { // 👉 - 用户表格
        XMGRecommendUserCell *cell  = [tableView dequeueReusableCellWithIdentifier:XMGUserCellId];
        XMGRecommendCategory *category = self.categories[self.categoryTable.indexPathForSelectedRow.row];
        
        cell.user = category.users[indexPath.row];
        
        return cell;
    }
}

#pragma mark - Table View delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.categoryTable) { // 👈 - 类别表格
        XMGRecommendCategory *category = self.categories[indexPath.row];
        if (category.users.count == 0) { // 这个被选中的类别 没有任何用户数据
#warning 补充
            // 取消之前的请求
            [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
            
            // 让 👉 - 用户表格 进入下拉刷新状态 (加载最新的用户数据)
            [self.userTable.header beginRefreshing];
        }
        
        // 刷新右边的表格
        [self.userTable reloadData];
        
        // 控制footer需要显示还是隐藏
        if (category.users.count == category.total) {
            self.userTable.footer.hidden = YES;
        }
    } else { // 👉 - 用户表格
        XMGLog(@"didSelectRow 👉 - 用户表格---%zd", indexPath.row);
    }
}
@end
