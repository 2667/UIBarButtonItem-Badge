//
//  XMGRecommendCategoryCell.m
//  百思不得姐
//
//  Created by xiaomage on 15/10/23.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGRecommendCategoryCell.h"
#import "XMGRecommendCategory.h"

@interface XMGRecommendCategoryCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIView *selectedIndicator;
@end

@implementation XMGRecommendCategoryCell

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    if (selected) { // 选中
        self.nameLabel.textColor = [UIColor redColor];
        self.selectedIndicator.hidden = NO;
    } else { // 取消选中
        self.nameLabel.textColor = [UIColor darkGrayColor];
        self.selectedIndicator.hidden = YES;
    }
}

- (void)setCategory:(XMGRecommendCategory *)category
{
    _category = category;
    
    self.nameLabel.text = category.name;
}
@end
