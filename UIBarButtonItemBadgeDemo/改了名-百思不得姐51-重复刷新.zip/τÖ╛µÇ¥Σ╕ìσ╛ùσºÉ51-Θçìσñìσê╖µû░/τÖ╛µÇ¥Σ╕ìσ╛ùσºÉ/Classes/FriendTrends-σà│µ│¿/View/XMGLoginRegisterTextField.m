//
//  XMGLoginRegisterTextField.m
//  百思不得姐
//
//  Created by xiaomage on 15/9/30.
//  Copyright © 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginRegisterTextField.h"

@interface XMGLoginRegisterTextField()
@end

@implementation XMGLoginRegisterTextField

- (void)awakeFromNib
{
    self.tintColor = [UIColor whiteColor];
    self.textColor = [UIColor whiteColor];
    self.placeholderColor = [UIColor grayColor];
}

/**
 *  当文本框开始编辑的时候会调用这个方法
 */
- (BOOL)becomeFirstResponder
{
    self.placeholderColor = [UIColor whiteColor];
    return [super becomeFirstResponder];
}

/**
 *  当文本框结束编辑的时候会调用这个方法
 */
- (BOOL)resignFirstResponder
{
    self.placeholderColor = [UIColor grayColor];
    return [super resignFirstResponder];
}

@end
